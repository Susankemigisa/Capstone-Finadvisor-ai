from langchain_core.tools import tool

@tool
def search_documents(query: str) -> str:
    """Search the user's uploaded financial documents for relevant information."""
    return f"[stub] Document search for '{query}' — Phase 7 (RAG) will implement this."