import os
import time
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from src.config.settings import settings
from src.utils.logger import get_logger
from src.utils.sanitizer import sanitize_error

logger = get_logger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("starting_up", app=settings.APP_NAME, env=settings.APP_ENV, debug=settings.DEBUG)

    if settings.LANGCHAIN_TRACING_V2 and settings.LANGCHAIN_API_KEY:
        os.environ["LANGCHAIN_TRACING_V2"] = "true"
        os.environ["LANGCHAIN_API_KEY"] = settings.LANGCHAIN_API_KEY
        os.environ["LANGCHAIN_ENDPOINT"] = settings.LANGCHAIN_ENDPOINT
        os.environ["LANGCHAIN_PROJECT"] = settings.LANGCHAIN_PROJECT
        logger.info("langsmith_enabled", project=settings.LANGCHAIN_PROJECT)
    else:
        os.environ["LANGCHAIN_TRACING_V2"] = "false"
        logger.info("langsmith_disabled")

    logger.info("available_models", models=[m["name"] for m in settings.get_available_models()])
    yield
    logger.info("shutting_down", app=settings.APP_NAME)


app = FastAPI(
    title=settings.APP_NAME,
    description="AI-powered financial advisory agent with multi-LLM support, RAG, and real-time market data.",
    version="1.0.0",
    docs_url="/docs" if settings.DEBUG else None,
    redoc_url="/redoc" if settings.DEBUG else None,
    lifespan=lifespan,
)

# ── CORS ──────────────────────────────────────────────────────
_origins = settings.get_allowed_origins()
if "*" in _origins or settings.APP_ENV == "production":
    _origins = ["*"]

app.add_middleware(
    CORSMiddleware,
    allow_origins=_origins,
    allow_credentials=False if "*" in _origins else True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.middleware("http")
async def log_requests(request: Request, call_next):
    start_time = time.time()
    response = await call_next(request)
    duration_ms = round((time.time() - start_time) * 1000)
    logger.info("request", method=request.method, path=request.url.path, status=response.status_code, duration_ms=duration_ms)
    return response


@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    safe_message = sanitize_error(exc)
    return JSONResponse(status_code=500, content={"detail": safe_message, "status": "error"})


# ── Routers ───────────────────────────────────────────────────
from src.api.routes import (
    auth, chat, portfolio, documents, market, analytics,
    billing, notifications, alerts, watchlist, goals, budget, tax, exports
)
from src.scheduler import start_scheduler, stop_scheduler


@app.on_event("startup")
async def startup_event():
    start_scheduler()


@app.on_event("shutdown")
async def shutdown_event():
    stop_scheduler()


# Existing routes
app.include_router(auth.router,          prefix="/auth",          tags=["Authentication"])
app.include_router(chat.router,          prefix="/chat",          tags=["Chat"])
app.include_router(portfolio.router,     prefix="/portfolio",     tags=["Portfolio"])
app.include_router(documents.router,     prefix="/documents",     tags=["Documents"])
app.include_router(market.router,        prefix="/market",        tags=["Market Data"])
app.include_router(analytics.router,     prefix="/analytics",     tags=["Analytics"])
app.include_router(billing.router,       prefix="/billing",       tags=["Billing"])
app.include_router(notifications.router, prefix="/notifications",  tags=["Notifications"])
app.include_router(alerts.router)

# New routes
app.include_router(watchlist.router,     prefix="/watchlist",     tags=["Watchlist"])
app.include_router(goals.router,         prefix="/goals",         tags=["Financial Goals"])
app.include_router(budget.router,        prefix="/budget",        tags=["Budget"])
app.include_router(tax.router,           prefix="/tax",           tags=["Tax Records"])
app.include_router(exports.router,       prefix="/export",        tags=["Exports"])


@app.get("/health", tags=["System"])
async def health_check():
    return {
        "status": "healthy",
        "app": settings.APP_NAME,
        "env": settings.APP_ENV,
        "available_models": settings.get_available_models(),
    }


@app.get("/", tags=["System"])
async def root():
    return {"message": f"Welcome to {settings.APP_NAME} API", "docs": "/docs", "health": "/health"}
