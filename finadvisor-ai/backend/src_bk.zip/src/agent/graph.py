from langgraph.graph import StateGraph, END
from langgraph.checkpoint.memory import MemorySaver

from src.agent.state import AgentState
from src.agent.nodes.planner import planner_node, should_continue
from src.agent.nodes.tool_executor import tool_executor_node
from src.utils.logger import get_logger

logger = get_logger(__name__)

# Short-term memory checkpointer (in-memory for now, swappable to Supabase later)
_checkpointer = MemorySaver()
_graph = None


def _build_graph():
    """
    Build and compile the LangGraph StateGraph.

    Flow:
        planner → (has tool calls?) → tool_executor → planner → ...
                → (no tool calls)  → END
    """
    builder = StateGraph(AgentState)

    # Add nodes
    builder.add_node("planner", planner_node)
    builder.add_node("tools", tool_executor_node)

    # Entry point
    builder.set_entry_point("planner")

    # After planner: check if we need tools or are done
    builder.add_conditional_edges(
        "planner",
        should_continue,
        {
            "tools": "tools",
            "end": END,
        },
    )

    # After tools: always go back to planner to process tool results
    builder.add_edge("tools", "planner")

    # Compile with memory checkpointer for short-term session memory
    graph = builder.compile(checkpointer=_checkpointer)
    logger.info("agent_graph_compiled")
    return graph


def get_graph():
    """Return the compiled graph (singleton — built once on first call)."""
    global _graph
    if _graph is None:
        _graph = _build_graph()
    return _graph


async def run_agent(
    user_message: str,
    user_id: str,
    session_id: str,
    model_id: str = "gpt-4o-mini",
    user_name: str = "",
    preferred_currency: str = "USD",
    preferred_language: str = "en",
    tier: str = "free",
    temperature: float = 0.3,
    top_p: float = 1.0,
    portfolio_summary: str = "",
    memories: list = None,
    rag_context: list = None,
) -> dict:
    """
    Run the agent for one user message turn.

    Handles:
    - Building the initial state
    - Running the graph with the session thread ID (for memory continuity)
    - Returning the final response, tools used, and token counts

    Returns a dict with:
        response: str — the agent's final text response
        tools_used: list — tools called during this turn
        prompt_tokens: int
        completion_tokens: int
        cost_usd: float
        error: str — empty if successful
    """
    from langchain_core.messages import HumanMessage
    from src.agent.state import default_state

    graph = get_graph()

    # Build the initial state for this turn
    state = default_state(
        user_id=user_id,
        session_id=session_id,
        model_id=model_id,
        user_name=user_name,
        preferred_currency=preferred_currency,
        preferred_language=preferred_language,
        tier=tier,
    )
    state["portfolio_summary"] = portfolio_summary
    state["memories"] = memories or []
    state["rag_context"] = rag_context or []
    state["messages"] = [HumanMessage(content=user_message)]

    # Thread config for LangGraph checkpointer (enables session memory)
    config = {"configurable": {"thread_id": session_id}}

    try:
        result = await graph.ainvoke(state, config=config)
    except Exception as e:
        logger.error("graph_run_failed", user_id=user_id, error=str(e))
        return {
            "response": "I encountered an error processing your request. Please try again.",
            "tools_used": [],
            "prompt_tokens": 0,
            "completion_tokens": 0,
            "cost_usd": 0.0,
            "error": str(e),
        }

    # Extract final response from last AI message
    messages = result.get("messages", [])
    response_text = ""
    for msg in reversed(messages):
        if hasattr(msg, "content") and msg.content and not hasattr(msg, "tool_call_id"):
            response_text = msg.content
            break

    return {
        "response": response_text or "I couldn't generate a response. Please try again.",
        "tools_used": result.get("tools_used", []),
        "prompt_tokens": result.get("prompt_tokens", 0),
        "completion_tokens": result.get("completion_tokens", 0),
        "cost_usd": result.get("cost_usd", 0.0),
        "error": result.get("error", ""),
    }


async def stream_agent(
    user_message: str,
    user_id: str,
    session_id: str,
    model_id: str = "gpt-4o-mini",
    user_name: str = "",
    preferred_currency: str = "USD",
    preferred_language: str = "en",
    tier: str = "free",
    temperature: float = 0.3,
    top_p: float = 1.0,
    portfolio_summary: str = "",
    memories: list = None,
    rag_context: list = None,
):
    """
    Stream the agent's response token by token.
    Yields string chunks as they arrive.
    Used by the SSE chat endpoint.
    """
    from langchain_core.messages import HumanMessage
    from src.agent.state import default_state

    graph = get_graph()

    state = default_state(
        user_id=user_id,
        session_id=session_id,
        model_id=model_id,
        user_name=user_name,
        preferred_currency=preferred_currency,
        preferred_language=preferred_language,
        tier=tier,
    )
    state["portfolio_summary"] = portfolio_summary
    state["memories"] = memories or []
    state["rag_context"] = rag_context or []
    state["messages"] = [HumanMessage(content=user_message)]

    config = {"configurable": {"thread_id": session_id}}

    tools_called = []

    try:
        async for chunk in graph.astream(state, config=config, stream_mode="messages"):
            if isinstance(chunk, tuple):
                message, metadata = chunk
                # Capture tool calls
                if hasattr(message, "tool_calls") and message.tool_calls:
                    for tc in message.tool_calls:
                        name = tc.get("name") if isinstance(tc, dict) else getattr(tc, "name", None)
                        if name and name not in tools_called:
                            tools_called.append(name)
                # Capture tool results (tool_call_id present = tool response)
                if hasattr(message, "name") and message.name and hasattr(message, "tool_call_id"):
                    if message.name not in tools_called:
                        tools_called.append(message.name)
                # Stream text tokens
                if (
                    hasattr(message, "content")
                    and message.content
                    and not hasattr(message, "tool_call_id")
                    and metadata.get("langgraph_node") == "planner"
                ):
                    yield message.content
    except Exception as e:
        logger.error("stream_failed", user_id=user_id, error=str(e))
        yield f"\n\nError: {str(e)}"

    # Yield tools as final metadata chunk
    if tools_called:
        import json
        yield f"__TOOLS_USED__:{json.dumps(tools_called)}"