from langchain_core.messages import ToolMessage
from langgraph.prebuilt import ToolNode

from src.agent.state import AgentState
from src.utils.logger import get_logger

logger = get_logger(__name__)


def tool_executor_node(state: AgentState) -> dict:
    """
    Executes all tool calls requested by the planner node.

    Uses LangGraph's built-in ToolNode under the hood, then
    tracks which tools were used for analytics.
    """
    messages = state.get("messages", [])
    if not messages:
        return {}

    last_message = messages[-1]
    if not hasattr(last_message, "tool_calls") or not last_message.tool_calls:
        return {}

    # Track tool names for analytics
    tool_names = [tc["name"] for tc in last_message.tool_calls]
    logger.info("executing_tools", tools=tool_names, user_id=state.get("user_id"))

    # Import all tools and build a ToolNode
    from src.tools import get_all_tools
    tools = get_all_tools()
    tool_node = ToolNode(tools)

    # Execute the tools
    try:
        result = tool_node.invoke(state)
    except Exception as e:
        logger.error("tool_execution_failed", tools=tool_names, error=str(e))
        # Return error tool messages so the agent can handle gracefully
        error_messages = []
        for tc in last_message.tool_calls:
            error_messages.append(
                ToolMessage(
                    content=f"Tool '{tc['name']}' failed: Please try a different approach.",
                    tool_call_id=tc["id"],
                )
            )
        return {"messages": error_messages}

    # Accumulate tools used for analytics
    existing_tools = state.get("tools_used", [])
    updated_tools = existing_tools + tool_names

    return {
        **result,
        "tools_used": updated_tools,
    }