from typing import Annotated, Any
from langgraph.graph.message import add_messages
from typing_extensions import TypedDict


class AgentState(TypedDict):
    messages: Annotated[list, add_messages]
    user_id: str
    session_id: str
    model_id: str
    user_name: str
    preferred_currency: str
    preferred_language: str
    tier: str
    portfolio_summary: str
    memories: list[str]
    tools_used: list[str]
    rag_context: list[dict]
    prompt_tokens: int
    completion_tokens: int
    cost_usd: float
    error: str
    requires_human_review: bool
    is_done: bool
    temperature: float
    top_p: float
    enabled_tools: list[str]


def default_state(
    user_id: str,
    session_id: str,
    model_id: str = "gpt-4o-mini",
    user_name: str = "",
    preferred_currency: str = "USD",
    preferred_language: str = "en",
    tier: str = "free",
    temperature: float = 0.3,
    top_p: float = 1.0,
) -> dict:
    return {
        "user_id": user_id,
        "session_id": session_id,
        "model_id": model_id,
        "user_name": user_name,
        "preferred_currency": preferred_currency,
        "preferred_language": preferred_language,
        "tier": tier,
        "temperature": temperature,
        "top_p": top_p,
        "enabled_tools": None,
        "portfolio_summary": "",
        "memories": [],
        "tools_used": [],
        "rag_context": [],
        "prompt_tokens": 0,
        "completion_tokens": 0,
        "cost_usd": 0.0,
        "error": "",
        "requires_human_review": False,
        "is_done": False,
    }