"""FinAdvisor AI test suite."""
